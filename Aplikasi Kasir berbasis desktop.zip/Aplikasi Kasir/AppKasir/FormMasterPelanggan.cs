﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AppKasir
{
    public partial class FormMasterPelanggan : Form
    {
        Koneksi Koon = new Koneksi();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;

        void kondisiAwal()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            MunculDataPelanggan();
        }
        void MunculDataPelanggan()
        {
            SqlConnection Conn1 = Koon.GetConn1();
            Conn1.Open();
            cmd = new SqlCommand("Select * from TB_PELANGGAN", Conn1);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TB_PELANGGAN");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TB_PELANGGAN";
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Refresh();
        }
        public FormMasterPelanggan()
        {
            InitializeComponent();
        }

        private void FormMasterPelanggan_Load(object sender, EventArgs e)
        {
            kondisiAwal();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "")
            {
                MessageBox.Show("Data tidak valid", "Error",
                 MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

            }
            else
            {
                result = MessageBox.Show("Simpan data ?", "Informasi", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Data tersimpan!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Insert into TB_PELANGGAN values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak tersimpan", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "")
            {
                MessageBox.Show("Pastikan Semua Form Terisi", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {
                result = MessageBox.Show("Edit data ?", "Informasi", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Data di Edit!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Update TB_PELANGGAN set NamaPelanggan='" + textBox2.Text + "',AlamatPelanggan ='" + textBox3.Text + "',TelephonePelanggan='" + textBox4.Text + "'where KodePelanggan='" + textBox1.Text + "'", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak teredit", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
          
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ;
            {
                SqlConnection Conn1 = Koon.GetConn1();
                cmd = new SqlCommand("select * from TB_PELANGGAN where KodePelanggan='" + textBox1.Text + "'", Conn1);
                Conn1.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    textBox1.Text = rd[0].ToString();
                    textBox2.Text = rd[1].ToString();
                    textBox3.Text = rd[2].ToString();
                    textBox4.Text = rd[3].ToString();
                }
                else
                {
                    MessageBox.Show("Data Tidak ada");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "")
            {
                MessageBox.Show("Pastikan Semua Form Terisi", "Error",
               MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {
                result = MessageBox.Show("Hapus data ?", "Informasi", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Data di Hapus!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Delete TB_PELANGGAN where KodePelanggan='" + textBox1.Text + "'", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak terhapus", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            kondisiAwal();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            SqlConnection Conn1 = Koon.GetConn1();

            cmd = new SqlCommand("select * from  TB_PELANGGAN where KodePelanggan like '%" + textBox5.Text + "%' or NamaPelanggan like '%" + textBox5.Text + "%'", Conn1);
            Conn1.Open();
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TB_PELANGGAN");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TB_PELANGGAN";
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
    }