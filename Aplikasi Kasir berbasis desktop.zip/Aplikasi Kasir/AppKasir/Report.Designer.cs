﻿
namespace AppKasir
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbHasil = new System.Windows.Forms.Label();
            this.BtSimpan = new System.Windows.Forms.Button();
            this.txtDaily = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtDaily);
            this.groupBox1.Controls.Add(this.BtSimpan);
            this.groupBox1.Controls.Add(this.lbHasil);
            this.groupBox1.Location = new System.Drawing.Point(178, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(442, 318);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Komentar";
            // 
            // lbHasil
            // 
            this.lbHasil.AutoSize = true;
            this.lbHasil.Location = new System.Drawing.Point(34, 290);
            this.lbHasil.Name = "lbHasil";
            this.lbHasil.Size = new System.Drawing.Size(30, 13);
            this.lbHasil.TabIndex = 1;
            this.lbHasil.Text = "Hasil";
            // 
            // BtSimpan
            // 
            this.BtSimpan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BtSimpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtSimpan.Location = new System.Drawing.Point(37, 159);
            this.BtSimpan.Name = "BtSimpan";
            this.BtSimpan.Size = new System.Drawing.Size(375, 39);
            this.BtSimpan.TabIndex = 2;
            this.BtSimpan.Text = "Simpan";
            this.BtSimpan.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtSimpan.UseVisualStyleBackColor = false;
            this.BtSimpan.Click += new System.EventHandler(this.BtSimpan_Click_1);
            // 
            // txtDaily
            // 
            this.txtDaily.Location = new System.Drawing.Point(37, 22);
            this.txtDaily.Name = "txtDaily";
            this.txtDaily.Size = new System.Drawing.Size(375, 115);
            this.txtDaily.TabIndex = 3;
            this.txtDaily.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(37, 215);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(375, 33);
            this.button1.TabIndex = 4;
            this.button1.Text = "Tutup";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "Report";
            this.Text = "Report";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtSimpan;
        private System.Windows.Forms.Label lbHasil;
        private System.Windows.Forms.RichTextBox txtDaily;
        private System.Windows.Forms.Button button1;
    }
}