﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//1
using System.Data.SqlClient;

namespace AppKasir
{
    public partial class FormMasterBarang : Form
    {
        Koneksi Koon = new Koneksi();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;

        void munculSatuan()
        {
            comboBox1.Items.Add("UNIT");
            comboBox1.Items.Add("PCS");
            comboBox1.Items.Add("BOX");
        }
        void kondisiAwal()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox5.Text = "";
            comboBox1.Text = "";
            munculSatuan();
            MunculDataBarang();
        }
        void MunculDataBarang()
        {
            SqlConnection Conn1 = Koon.GetConn1();
            Conn1.Open();
            cmd = new SqlCommand("Select * from TB_BARANG", Conn1);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TB_BARANG");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TB_BARANG";
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Refresh();
        }
        public FormMasterBarang()
        {
            InitializeComponent();
        }

        private void FormMasterBarang_Load(object sender, EventArgs e)
        {
            kondisiAwal();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox5.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {

                MessageBox.Show("Data tidak valid", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {
                result = MessageBox.Show("Simpan data ?", "Informasi", MessageBoxButtons.YesNo,
                  MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Data tersimpan!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Insert into TB_BARANG values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox5.Text + "','" + comboBox1.Text + "')", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak tersimpan", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox5.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {
                MessageBox.Show("Pastikan Semua Form Terisi", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {
                result = MessageBox.Show("Edit data ?", "Informasi", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {

                    MessageBox.Show("Data di Edit!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Update TB_BARANG set NamaBarang='" + textBox2.Text + "',HargaJual='" + textBox3.Text + "',JumlahBarang='" + textBox5.Text + "',SatuanBarang='" + comboBox1.Text + "'where KodeBarang='" + textBox1.Text + "'", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak teredit", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) ;
            {
                SqlConnection Conn1 = Koon.GetConn1();
                cmd = new SqlCommand("select * from TB_BARANG where KodeBarang='" + textBox1.Text + "'", Conn1);
                Conn1.Open();
                cmd.ExecuteNonQuery();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    textBox1.Text = rd[0].ToString();
                    textBox2.Text = rd[1].ToString();
                    textBox3.Text = rd[2].ToString();
                    textBox5.Text = rd[3].ToString();
                    comboBox1.Text = rd[4].ToString();
                }
                else
                {
                    MessageBox.Show("Data Tidak ada");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result;
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {
                MessageBox.Show("Pastikan Semua Form Terisi", "Error",
               MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            else
            {
                result = MessageBox.Show("Hapus data ?", "Informasi", MessageBoxButtons.YesNo,
           MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Data di Hapus!", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                    SqlConnection Conn1 = Koon.GetConn1();
                    cmd = new SqlCommand("Delete TB_BARANG where KodeBarang='" + textBox1.Text + "'", Conn1);
                    Conn1.Open();
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Data tidak terhapus", "Informasi", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            SqlConnection Conn1 = Koon.GetConn1();

            cmd = new SqlCommand("select * from  TB_BARANG where KodeBarang like '%" + textBox6.Text + "%' or NamaBarang like '%" + textBox6.Text + "%'", Conn1);
            Conn1.Open();
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TB_BARANG ");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TB_BARANG ";
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            kondisiAwal();
        }
    }
    }
