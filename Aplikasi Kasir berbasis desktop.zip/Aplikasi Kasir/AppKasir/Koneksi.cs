﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace AppKasir
{
    class Koneksi
    {
        //2
        public SqlConnection GetConn1()
        {
            SqlConnection Conn1 = new SqlConnection();
            Conn1.ConnectionString = "Data Source = DESKTOP-OJD2KER; Initial Catalog = DB_APP; Integrated Security = True";
            return Conn1;
        }
    }
}